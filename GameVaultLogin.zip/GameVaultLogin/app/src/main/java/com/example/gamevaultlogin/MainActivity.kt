package com.example.formularioregistro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gamevaultlogin.R

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RegisterScreen()
        }
    }
}

@Composable
fun RegisterScreen() {
    var nombre by remember { mutableStateOf("") }
    var correo by remember { mutableStateOf("") }
    var claveRegistro by remember { mutableStateOf("") }
    var verificarClave by remember { mutableStateOf("") }
    var mensaje by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFEDF2F7))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        Image(
          painter = painterResource(id = R.drawable.logo),
           contentDescription = "Logo",
           modifier = Modifier.height(250.dp).padding(bottom = 64.dp)
        )

        ///ingreso nombre
        TextField(
            value = nombre,
            onValueChange = { nombre = it },
            label = { Text("Usuario") },
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))
        /// correo electronico
        TextField(
            value = correo,
            onValueChange = { correo = it },
            label = { Text("Correo Electronico") },
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        TextField(
            value = claveRegistro,
            onValueChange = { claveRegistro = it },
            label = { Text("Contraseña") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation()
        )

        Spacer(modifier = Modifier.height(12.dp))

        TextField(
            value = verificarClave,
            onValueChange = { verificarClave = it },
            label = { Text("Vuelve a escribir Contraseña") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(modifier = Modifier.height(12.dp))


        Spacer(modifier = Modifier.height(12.dp))
        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                mensaje = when {
                    nombre.isBlank() -> "El campo nombre no está completado"
                    correo.isBlank() -> "El campo correo no está completado"
                    !correo.contains("@") || !correo.endsWith(".com") -> "El correo no es válido"
                    claveRegistro.isBlank() -> "El campo contraseña no está completado "
                    verificarClave.isBlank() -> "Debes verificar la contraseña"
                    claveRegistro != verificarClave -> "Las contraseñas no coinciden"
                    else -> "Usuario registrado correctamente\nNombre: $nombre\nCorreo: $correo\n"
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF2196F3),
                contentColor = Color(0xFF000000))
        ) {
            Text("Registrar")
        }




        Spacer(modifier = Modifier.height(20.dp))

        if (mensaje.isNotEmpty()) {
            Text(
                text = mensaje,
                fontSize = 18.sp,
                color = if (mensaje.contains("✅")) Color(0xFF2E7D32) else Color(0xFFC62828)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun RegisterPreview() {
    RegisterScreen()
}